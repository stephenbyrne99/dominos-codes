self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ba7c7d4ac2ffb7fefcd59014786100c4",
    "url": "/index.html"
  },
  {
    "revision": "98e80d12f20533abac59",
    "url": "/static/css/main.61cd4f2b.chunk.css"
  },
  {
    "revision": "69a3985293946e9f9bee",
    "url": "/static/js/2.d9e7bddd.chunk.js"
  },
  {
    "revision": "5586a95853ee43deda1fb4da37dc3fc8",
    "url": "/static/js/2.d9e7bddd.chunk.js.LICENSE"
  },
  {
    "revision": "98e80d12f20533abac59",
    "url": "/static/js/main.0b6723b0.chunk.js"
  },
  {
    "revision": "482e6148571d04602183",
    "url": "/static/js/runtime-main.503b74f0.js"
  },
  {
    "revision": "dfc9f6b78013b3d3baadc66342428d17",
    "url": "/static/media/logo.dfc9f6b7.png"
  }
]);